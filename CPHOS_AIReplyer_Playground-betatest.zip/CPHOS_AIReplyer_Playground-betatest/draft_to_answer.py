from gpt_utils import get_answer_from_gpt

def final_answer(user_question,hint_str):

    gpt_api_key = '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'

    engine = 'gpt-3.5-turbo'

    instruction_str = "Instructions: Create a brief answer to the question. Use the hint given in the prompt."\
                        "Most of the information in the hint is irrelevant. Select the relevant information to answer the question."\
                        'You must be careful when you select information.'\
                        "Don't use irrelevant information. Don't add any additional information."\
                        "Don't mention irrelevant content! Your answer should be closely relevant to the question."\
                        "The answer should be short and concise."\
                        "You must use Chinese to answer. Use '您' to call the questioner."
                        #A planned part: "If irrelevant words appear in the question(very seldom case), only say '对不起，我暂时还不清楚这个问题的答案，请咨询人工服务。'"
    question = ''.join(['Question: Select useful information in the hint to answer: ', user_question])
    #This part we let LLM choose the relevant information and gereate the final answer.
    hint = ''.join('Hint: ' + hint_str)

    prompt = '\n'.join([question, hint, instruction_str])

    answer = get_answer_from_gpt(gpt_api_key, prompt, engine)

    return answer