from search_pdf_utils import SemanticSearch, load_recommender
def get_hint(user_question):
    recommender_1 = SemanticSearch()
    pdf_path_1 = 'references/question.pdf'
    pdf_path_2 = 'references/学校老师小程序使用指南230323.pdf' 

    load_recommender(recommender_1, pdf_path_1)
    result_list = recommender_1(user_question) #load the first recommender

    load_recommender(recommender_1, pdf_path_2)
    result_list += recommender_1(user_question) #load the second recommender

    hint_str = '|||'.join(result_list) #The first recommender has already been parted into sections. Here we part the second recommendr.
    hint_str = hint_str.replace('|||','\n|||\n') #Seperate different part.
    return hint_str
