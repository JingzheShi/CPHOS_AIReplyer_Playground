from gpt_utils import get_answer_from_gpt

def get_draft(user_question,hint_str):

    gpt_api_key = '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'

    engine = 'gpt-3.5-turbo'

    instruction_str = "Instructions: The file is given in the prompt."\
                        "The hint is made up of different sections, seperated by'|||'."\
                        "Create titles for the sections you give me."\
                        "Reorganize the language, but don't lose any content."\
                        "Don't add any additional information."\
                        "The answer should be concise. Answer step-by-step."\
                        "You must use Chinese to answer. Use '您' to call the questioner."
        
    question = 'Search 3 sections in the file that are the most relevant to ' + user_question + ' and return me the whole 3 sections.'
    # This part we let LLM to classify and label different sections of the hint, and screen the information tentatively.

    hint = ''.join('File: ' + hint_str)

    prompt = '\n'.join([question, hint, instruction_str])

    answer = get_answer_from_gpt(gpt_api_key, prompt, engine)

    return answer