def answer_user_question(user_wechat_nickname, user_question):
    try:
        from hint_search import get_hint
        hint_str = get_hint(user_question)#Search relevant information from pdf, and seperate them into sections.

        from hint_to_draft import get_draft
        draft_str = get_draft(user_question,hint_str) #Classify and label the sections. Select 3 relevant sections.
        #Test: print(draft_str)

        from draft_to_answer import final_answer
        return final_answer(user_question,draft_str) #Select information from 3 chosen sections and gererate the answer.
    except Exception as e:
        print(e)
        return 'an Error of type ' + str(type(e)) + ' has occurred.'
#Test: print(answer_user_question('user_wechat_nickname', '卓永琪是上海第二')